import { createAction } from "@reduxjs/toolkit";

export const clearTasksAndTodolists = createAction("common/clear-tasks-todolists");
